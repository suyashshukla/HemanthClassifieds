import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Ad } from 'src/app/classifieds/Model/ad.model';
import { Ads } from 'src/app/classifieds/Model/Ads';
import { AdInfo } from './Model/adinfo.model';
import { Publisher } from './Model/publisher.model';
import { Image } from './Model/image.model';

@Injectable({
  providedIn: 'root'
})
export class ClassifiedService {
  adInfo: AdInfo ={
    id: 1,
    userId: 1,
    date: new Date('2019-05-18'),
    price: 83700,
    adTitle: 'Yamaha YZF R15',
    categoryicon: 'fas fa-motorcycle',
    categoryName: 'VEHICLE',
    offerCount: 12,
    commentCount: 18,
    description: 'The Yamaha R15 v3 is a premium fully faired motorcycle in the 150cc segment.',
    adType: 'Sale',
    expiryDate:new Date('2019-05-18'),
    contactFlag: true
  
  };
  publisher:Publisher={
    id:1,
    name:'Rajesh Ram Krishna',
    icon:'../assets/icon/user-icon.png',
    phone: 965430990,
    mail: 'rajesh.ram@xyz.com',
    Location: 'Hyderabad Corp office'
  }
  images: Image[] = [
    {url:'bike-yamaha.jpg'},
    {url:'bike-yamaha1.jpg'},
    {url:'harley.jpg'},
    {url:'bike-yamaha.jpg'},
    {url:'bike-yamaha.jpg'},
    {url:'bike-yamaha.jpg'}
  ];
  constructor() { }

  getAds(): Observable<Ad[]> {
    return of(Ads);
  }
   
  getAd(id):Observable<AdInfo>{
    return of(this.adInfo);
  }
  getUser(id:number):Observable<Publisher>{
     return of(this.publisher);
  }
  getImageLinks(id:number):Observable<Image[]>{
    return of(this.images);
  }
}
