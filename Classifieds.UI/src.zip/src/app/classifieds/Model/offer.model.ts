export class OfferAd {
    userId: number;
    adId: number;
    message: string;
    price: number;
    madeon: Date;
} 