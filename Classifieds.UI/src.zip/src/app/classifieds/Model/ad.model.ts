export class Ad {
        id: number;
        userIconUri: string;
        userName: string;
        date: Date;
        imageLink: string;
        price: number;
        adTitle: string;
        categoryicon: string;
        categoryName: string;
        offerCount: number;
        commentCount: number;
        description: string;
        Location: string;
        adType: string;
        expiryDate: Date;
  }