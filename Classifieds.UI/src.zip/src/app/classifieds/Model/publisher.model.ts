export class Publisher {
    id: number;
    name: string;
    icon: string;
    phone: number;
    mail: string;
    Location: string;
}