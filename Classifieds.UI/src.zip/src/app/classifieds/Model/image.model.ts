export class Image{
    url: string;
}