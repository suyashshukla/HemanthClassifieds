export class ReportAd {
      userId: number;
      adId: number;
      message: string;
      madeon:Date;
} 