export class AdInfo {
    id: number;
    userId: number;
    date: Date;
    price: number;
    adTitle: string;
    categoryicon: string;
    categoryName: string;
    offerCount: number;
    commentCount: number;
    description: string;
    adType: string;
    expiryDate: Date;
    contactFlag: boolean;
}