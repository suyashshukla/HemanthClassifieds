import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-classifieds',
  templateUrl: './classifieds.component.html',
  styleUrls: ['./classifieds.component.css']
})
export class ClassifiedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
