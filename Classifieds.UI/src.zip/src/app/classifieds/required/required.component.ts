import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-required',
  templateUrl: './required.component.html',
  styleUrls: ['./required.component.css']
})
export class RequiredComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
