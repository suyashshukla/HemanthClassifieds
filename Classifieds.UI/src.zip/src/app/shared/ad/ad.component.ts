import { Component, OnInit, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { ClassifiedService } from 'src/app/classifieds/classified.service';
import { AdInfo } from 'src/app/classifieds/Model/adinfo.model';
import { Image } from 'src/app/classifieds/Model/image.model';
import { ActivatedRoute, Params } from '@angular/router';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-ad',
  templateUrl: './ad.component.html',
  styleUrls: ['./ad.component.css']
})
export class AdComponent implements OnInit, OnDestroy {
  paramSubscription: Subscription;
  ad: AdInfo;
  imageLinks: string[];
  images: Image[];
  id: number;
  constructor(private location: Location,private route: ActivatedRoute, private classifiedService: ClassifiedService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.getAd(this.id);
    this.getImages(this.id);
    this.paramSubscription = this.route.params
    .subscribe(
      (params: Params) => {
        this.id = params['id'];
        this.getAd(this.id);
        this.getImages(this.id);
      }
    );
  }
  goBack() {
    this.location.back();
  }
  onImageSelected(url: string) {
   console.log(url + 'selected');
  }
  getAd(id: number): void {
    this.classifiedService.getAd(id)
        .subscribe(ad => this.ad = ad);
  }
  getImages(id: number): void{
    this.classifiedService.getImageLinks(id)
          .subscribe(images => this.images = images);
    this.imageLinks = this.images.map(a => a.url);
  }
  ngOnDestroy() {
    this.paramSubscription.unsubscribe();
}
}
