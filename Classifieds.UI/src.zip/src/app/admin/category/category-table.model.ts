export class CategoryAttributes{
    category:string;
    description:string;
    createdBy:string;
    createdOn:Date;
}