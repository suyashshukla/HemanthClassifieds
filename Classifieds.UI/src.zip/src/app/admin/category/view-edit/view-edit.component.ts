import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-edit',
  templateUrl: './view-edit.component.html',
  styleUrls: ['./view-edit.component.css']
})
export class ViewEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
