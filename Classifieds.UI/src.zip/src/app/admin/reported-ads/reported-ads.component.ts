import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reported-ads',
  templateUrl: './reported-ads.component.html',
  styleUrls: ['./reported-ads.component.css']
})
export class ReportedAdsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
