import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ads-lists',
  templateUrl: './ads-lists.component.html',
  styleUrls: ['./ads-lists.component.css']
})
export class AdsListsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
