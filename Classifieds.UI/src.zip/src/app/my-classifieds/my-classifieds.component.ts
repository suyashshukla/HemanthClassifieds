import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-classifieds',
  templateUrl: './my-classifieds.component.html',
  styleUrls: ['./my-classifieds.component.css']
})
export class MyClassifiedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
