import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-images',
  templateUrl: './add-images.component.html',
  styleUrls: ['./add-images.component.css']
})
export class AddImagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
