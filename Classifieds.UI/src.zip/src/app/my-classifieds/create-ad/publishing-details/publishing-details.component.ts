import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-publishing-details',
  templateUrl: './publishing-details.component.html',
  styleUrls: ['./publishing-details.component.css']
})
export class PublishingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
