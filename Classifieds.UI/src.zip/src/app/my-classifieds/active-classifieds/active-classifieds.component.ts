import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-classifieds',
  templateUrl: './active-classifieds.component.html',
  styleUrls: ['./active-classifieds.component.css']
})
export class ActiveClassifiedsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
