export class PublisherModel
{
    adId : number;
    createdOn: string;
    userIconUri: string;
    userName : string;
    location: string;
    emailId : string;
    phoneNumber : number;
    expiryDaysLeft : number;
}