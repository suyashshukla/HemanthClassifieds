import { Directive, ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appScrolldown]'
})
export class ScrolldownDirective{

  constructor(el:ElementRef) {
    
   }
   
 
}
