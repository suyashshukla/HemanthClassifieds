export class Chat{
    offerId:number;
    userName:string;
    message:string;
    time:Date;
}