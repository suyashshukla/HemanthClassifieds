export class DeletedAds{
    adName:string;
    adThumbnail:string;
    time:Date;
}