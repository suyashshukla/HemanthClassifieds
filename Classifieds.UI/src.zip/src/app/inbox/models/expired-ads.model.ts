export class ExpiredAds{
    adName:string;
    adThumbnail:string;
    removedBy:string;
    status:string;
    time:Date;
}