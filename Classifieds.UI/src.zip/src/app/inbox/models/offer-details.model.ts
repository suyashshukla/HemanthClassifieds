export class OfferDetails{
    offerId:number;
    userName:string;
    adName:string;
    adThumbnail:string;
    amount:number;
    time:Date;
}