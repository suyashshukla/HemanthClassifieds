export class ReportedAds{
    adName:string;
    adThumbnail:string;
    removedBy:string;
    time:Date;
}